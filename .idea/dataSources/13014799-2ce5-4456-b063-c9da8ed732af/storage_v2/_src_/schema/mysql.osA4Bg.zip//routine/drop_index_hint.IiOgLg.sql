create
    definer = rdsAdmin@localhost procedure drop_index_hint(IN hint_id int)
BEGIN delete from mysql.rds_index_hints where id =hint_id; FLUSH RDS_INDEX_HINTS; END;

