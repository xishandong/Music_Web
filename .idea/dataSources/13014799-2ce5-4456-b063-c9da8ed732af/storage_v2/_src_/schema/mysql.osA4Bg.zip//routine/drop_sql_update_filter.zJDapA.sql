create
    definer = rdsAdmin@localhost procedure drop_sql_update_filter() sql security invoker
BEGIN delete from mysql.rds_sql_filter_rules where type ='UPDATE'; FLUSH SQL_FILTERS; END;

