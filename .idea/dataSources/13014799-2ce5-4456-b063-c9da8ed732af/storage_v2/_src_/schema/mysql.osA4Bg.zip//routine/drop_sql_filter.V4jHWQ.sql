create
    definer = rdsAdmin@localhost procedure drop_sql_filter(IN filter_id int) sql security invoker
BEGIN delete from mysql.rds_sql_filter_rules where item_id =filter_id; FLUSH SQL_FILTERS; END;

