create
    definer = rdsAdmin@localhost procedure add_sql_select_filter(IN statement varchar(1024), IN conn int)
    sql security invoker
BEGIN CALL add_sql_filter(0, statement, conn); END;

