create
    definer = rdsAdmin@localhost procedure drop_index_hints()
BEGIN delete from mysql.rds_index_hints; FLUSH RDS_INDEX_HINTS; END;

