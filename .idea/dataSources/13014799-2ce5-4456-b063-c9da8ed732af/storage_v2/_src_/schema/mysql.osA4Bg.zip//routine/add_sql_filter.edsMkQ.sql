create
    definer = rdsAdmin@localhost procedure add_sql_filter(IN type_id int, IN statement varchar(1024), IN conn int)
    sql security invoker
body:BEGIN if (conn < 0) THEN select "max_concurrency can't less than 0." as error; LEAVE body; end if; if (length(statement) > 1024) THEN select "SQL length can't more than 1024" as error; LEAVE body; end if; if (type_id = 0) THEN insert into mysql.rds_sql_filter_rules(type, max_concurrency, key_str) values('SELECT', conn, statement); ELSEIF (type_id = 1) THEN insert into mysql.rds_sql_filter_rules(type, max_concurrency, key_str) values('UPDATE', conn, statement); ELSEIF (type_id = 2) THEN insert into mysql.rds_sql_filter_rules(type, max_concurrency, key_str) values('DELETE', conn, statement); ELSE select "The value of type_id must be set to 0, 1 or 2." as error; LEAVE body; end if; FLUSH SQL_FILTERS; END;

