create
    definer = rdsAdmin@localhost procedure add_sql_update_filter(IN statement varchar(1024), IN conn int)
    sql security invoker
BEGIN CALL add_sql_filter(1, statement, conn); END;

