create
    definer = rdsAdmin@localhost procedure add_index_hint(IN schema_name varchar(128), IN table_name varchar(128),
                                                          IN index_name varchar(128), IN statement varchar(1024))
body:BEGIN if (length(schema_name) > 128) THEN select "TABLE_SCHEMA length can't more than 128." as error; LEAVE body; end if; if (length(table_name) > 128) THEN select "TABLE_LENGTH length can't more than 128" as error; LEAVE body; end if; if (length(index_name) > 128) THEN select "INDEX_LENGTH length can't more than 128" as error; LEAVE body; end if; if (length(statement) > 1024) THEN select "SQL length can't more than 1024" as error; LEAVE body; end if; insert into mysql.rds_index_hints(db_name, table_name, force_index, key_str) values(schema_name, table_name, index_name, statement); FLUSH RDS_INDEX_HINTS; END;

