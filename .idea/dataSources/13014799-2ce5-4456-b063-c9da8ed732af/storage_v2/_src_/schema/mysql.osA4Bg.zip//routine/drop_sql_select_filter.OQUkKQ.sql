create
    definer = rdsAdmin@localhost procedure drop_sql_select_filter() sql security invoker
BEGIN delete from mysql.rds_sql_filter_rules where type ='SELECT'; FLUSH SQL_FILTERS; END;

